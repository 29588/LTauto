> Due to a third-party risk dispute, this script stopped sharing
> 由于第三方风险争议，此脚本停止分享。
> ***
### 自己的收集使用教程具体找作者'
### 1. 20210308 ，抄了个49任务的，不知道能不能用，[49源地址](https://github.com/lz0423/ceshi)
 ### fork 好后，点击 Settings 、 secrets 、 New repository secrets 进行添加相关数据
 ![Snipaste_2021-03-01_05-36-51](https://user-images.githubusercontent.com/79479594/109432788-4182de00-7a50-11eb-9ebf-3da345f21e35.png)

 参数如下：  
|  Name | Value  |
|  --- | --- |
| ENABLE_UNICOM  | 直接填写 true |
| UNICOM_APPID  | 填写获取的 appid |
| UNICOM_USER  | 手机号 |
| UNICOM_PASSWORD  | 服务密码 |    
#### 依次添加共四项
![image](https://user-images.githubusercontent.com/79479594/109432827-6d05c880-7a50-11eb-8682-50405d7d66dd.png)

#### 添加以上数据之后，进入 actions ，点击绿色长条启用它，   
![QQ图片20210301054304](https://user-images.githubusercontent.com/79479594/109433119-1600f300-7a52-11eb-8ad2-0f7739d407c8.png)
  
#### 进入日常任务daily-task，然后Enable Workflow启用工作流  
![Snipaste_2021-03-01_05-46-47](https://user-images.githubusercontent.com/79479594/109433041-a428a980-7a51-11eb-8825-8f3e17813a53.png)

#### 回到代码Code处，进入自述文档README.md,随意编辑它，比如删除此处的    。再点击下方绿色Commit changes保存。
![Snipaste_2021-03-01_05-51-46](https://user-images.githubusercontent.com/79479594/109433473-ce7b6680-7a53-11eb-9a1a-c095ab45fcf5.png)
    
![Snipaste_2021-03-01_05-54-48](https://user-images.githubusercontent.com/79479594/109433247-bbb46200-7a52-11eb-91be-c48f28503c0f.png)
![Snipaste_2021-03-01_05-59-32](https://user-images.githubusercontent.com/79479594/109433404-7e9c9f80-7a53-11eb-91d5-73f2429e2409.png)

#### 并发数我改成2了。
